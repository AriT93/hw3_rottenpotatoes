require 'spec_helper'

describe MoviesController do

end
